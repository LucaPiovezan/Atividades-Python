from flask import Flask, request, render_template_string

app = Flask(__name__)

usuarios = [
    {"usuario": "luca", "senha": "12402168"},
    {"usuario": "joao", "senha": "cotemig2026"},
    {"usuario": "janaina", "senha": "cotemig2026"}  
]

def show_the_login_form():
    return render_template_string("""
        <h2>Login</h2>

        <form method="POST">
            <input type="text" name="usuario" placeholder="Usuário"><br><br>

            <input type="password" name="senha" placeholder="Senha"><br><br>

            <button type="submit">Entrar</button>
        </form>
    """)

def do_the_login():
    usuario_digitado = request.form.get("usuario")
    senha_digitada = request.form.get("senha")

    for usuario in usuarios:

        if (
            usuario_digitado == usuario["usuario"]
            and senha_digitada == usuario["senha"]
        ):
            return f"<h1>Bem-vindo, {usuario_digitado}!</h1>"

    return "<h1>Login inválido</h1>"

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        return do_the_login()
    else: 
        return show_the_login_form()

if __name__ == "__main__":
    app.run(debug=True)