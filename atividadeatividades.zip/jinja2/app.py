from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html',nome="Estudante ")

@app.route('/alunos')
def alunos():
    alunos = [{"nome": "aaaaa", "idade": 18}, {"nome": "bbbb", "idade": 20}, {"nome": "cccc", "idade": 22}]
    return render_template('alunos.html', alunos=alunos)

@app.route('/usuario')
def usuario():
    usuario = {"nome": "aaaaa", "email": "aaaa@email.com"}
    return render_template('usuario.html', usuario=usuario)

@app.route('/lista_nomes')
def lista_nomes():
    nomes = ["aaaaaa", "bbbbbb", "ccccc", "ddddd"]
    return render_template('lista_nomes.html', nomes=nomes)

@app.route('/notas')
def notas():
    alunos_notas = [
        {"nome": "aaaaa", "nota": 8.5},
        {"nome": "bbbbb", "nota": 5.0},
        {"nome": "ccccc", "nota": 7.0}
    ]
    return render_template('notas.html', alunos=alunos_notas)

if __name__ == '__main__':
    app.run(debug=True)