from flask import Flask

app = Flask(__name__) 

@app.route('/') 
def ola_mundo():
    return 'Olá, Mundo!' 

@app.route('/hello') 
def hello():
    return 'Hello, World!'

if __name__ == '__main__':
    app.run(debug=True) 